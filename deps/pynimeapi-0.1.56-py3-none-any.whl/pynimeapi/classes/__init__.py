from pynimeapi.classes.color import bcolors
from pynimeapi.classes.datatype import *